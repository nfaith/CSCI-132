
/**
 * Write a description of class Driver here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Driver
{
   public static void main(String [] args)
   {
       Team broncos = new Team(7, "Broncos");
       Team cats = new Team(4, "Bobcats");
       
       cats.calculateScore();
       broncos.calculateScore();
       
       broncos.printResult();
       cats.printResult();
       
    }
}
