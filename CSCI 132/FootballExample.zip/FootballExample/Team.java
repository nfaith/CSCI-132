
/**
 * Write a description of class Football here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Team
{
    
    private int amtTds;
    private int score;
    private String name;
    
    public Team(int in_amtTds, String in_name)
    {
       amtTds = in_amtTds;
       name = in_name;
       
    }

    public void calculateScore()
    {
        int touchdown = 6;
        score = amtTds * touchdown + amtTds;
    }
    
    public void printResult()
    {
        System.out.println(name + " scored: " + score );
    }

}
