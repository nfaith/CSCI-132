


public class Broncos
{
    
    public static void main(String [] args)
    {
        int touchdown = 6;        
        int amtTDs = 7;         
        int score = amtTDs + touchdown * amtTDs;
        
        System.out.println("Broncos scored: " + score  + " Broncos Win");
        
        
        
        System.out.println("Broncos scored: " + ( amtTDs + touchdown * amtTDs ) + " Broncos Win");
 
    }
    
}