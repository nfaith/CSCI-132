/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package llsinglelistexamplefromscratch;

/**
 *
 * @author Hunter
 */
public class LinkedList {
    
    private Node first;
    
    LinkedList(){
       first = null;
    }
    void add(int temp){
        Node n = new Node(temp);
        n.setNext(first);
        first = n;
    }
    boolean delete(int temp){ 
        Node iter = first;
        Node lagptr = first;
        while(iter != null)
        {
            if(iter.getData() == temp)
            {
                if(iter == first)
                    first = first.getNext();
                else
                    lagptr.setNext(iter.getNext());
                
                return true;
            }
            lagptr = iter;
            iter = iter.getNext();
            
        }
        return false;
     }
    
    public int giveCount()
    {
        return count(first);
    }
    private int count(Node iter)
    {
        if(iter == null)
           return 0;
        else
            return 1 + count(iter.getNext());
        
    }
    void print(){
        Node iter = first;
        while(iter != null)
        {
           System.out.println(iter.getData());
           iter = iter.getNext();
        }
    
    }
    void deleteList(){ first = null; }
    boolean isEmpty(){ return (first == null); }
    
}
