/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package llsinglelistexamplefromscratch;

/**
 *
 * @author Hunter
 */
public class LLSingleListExampleFromScratch {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LinkedList list = new LinkedList();
        for (int i = 0; i<15; i++)
        {
            list.add(i*20);
        }
        System.out.println("I have " + list.giveCount() + " element(s) in my list");
        //list.print();
        
    }
    
}
